for(i=1;i<=10;i++)
{
    var a=i*2
    console.log(i+"*"+"2"+"="+a)

}



/*
for(i=1;i<=10;i++)
{
   if(i%2 ==0)
    {
    console.log(i)
   }
}
*/
/* var facttor ="Surya"
var fPlayer ="Suny"
var fMovie = "Singam"
function Favarite(){
    console.log("Favarite Actor is :"+facttor)
    console.log("Favarite Player is : "+fPlayer)
    console.log("Faverite Movie is :"+fMovie)
}
Favarite()
*/