export class User {
    id:number=0;
    password:string="";
    name:string="";
    dob:string="";
    emailid:string="";
    address:string="";
    gender:string="";
    mobile:string="";
    
}
