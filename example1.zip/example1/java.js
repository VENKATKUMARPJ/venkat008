function colorBox() {
    var input = document.getElementById("numberInput").value;
    var errorMessage = document.getElementById("errorMessage");
    errorMessage.innerHTML = "";
    
    if (isNaN(input) || input < 1 || input > 9) {
      errorMessage.innerHTML = "Please input a number between 1-9";
      return;
    }
    
    var selectedBox = document.getElementById("box" + input);
    var allBoxes = document.getElementsByClassName("box");
    
    for (var i = 0; i < allBoxes.length; i++) {
      if (allBoxes[i] !== selectedBox) {
        allBoxes[i].style.backgroundColor = "white";
      }
    }
    
  selectedBox.style.backgroundColor = "green";
  }